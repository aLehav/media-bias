"""Scrapy pipelines"""

from .wiki_pipeline import WikiPipeline